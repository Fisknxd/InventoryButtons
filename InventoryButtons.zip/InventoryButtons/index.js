import PogObject from "../PogData"

function drawRoundedRect(color, x, y, width, height, radius) {
    Java.type("gg.essential.universal.UMatrixStack").Compat.INSTANCE.runLegacyMethod(Java.type("gg.essential.universal.UMatrixStack").Compat.INSTANCE.get(), () => {
        Java.type("gg.essential.elementa.components.UIRoundedRectangle").Companion.drawRoundedRectangle(
            Java.type("gg.essential.universal.UMatrixStack").Compat.INSTANCE.get(),
            x, y,
            x + width,
            y + height,
            radius, color
        )
    })
}

class InventoryButton {
    constructor(x, y, size, item, func, itemID, commandString) {
        this.x = x
        this.y = y
        this.size = size
        this.item = item
        this.func = func
        this.itemID = itemID
        this.commandString = commandString

        this.darkmode = new java.awt.Color(33 / 255, 33 / 255, 33 / 255, 1)
        this.clicked = false
        this.mx = 0
        this.my = 0
        this.Hovered = false
    }

    mouseClick(btn) {
        this.update() 
        if (this.Hovered && !isOpened()) {
            if (btn === 0) this.func()
        }
    }

    guiMouseClick(btn) {
        this.update()
        if (this.Hovered) {
            this.clicked = (btn === 0)
        }
    }

    update() {
        this.mx = Client.getMouseX()
        this.my = Client.getMouseY()
        this.Hovered = this.mx >= this.x && this.mx <= this.x + this.size && this.my >= this.y && this.my <= this.y + this.size
    }

    draw() {
        this.update() 
        if (this.Hovered) {
            drawRoundedRect(this.darkmode.darker().darker(), this.x - (this.size/5)/2, this.y - (this.size/5)/2, this.size + this.size/5, this.size + this.size/5, 4)
        }
        drawRoundedRect(this.darkmode, this.x, this.y, this.size, this.size, 4)
        this.item.draw(this.x, this.y, this.size/16)
    }
}


export const config = new PogObject("InventoryButtons", {
    enabled: true,
    buttons: []
}, "data.json")

let liveButtons = []

function dehydrateButtons() {
    config.buttons = liveButtons.map(button => ({
        x: button.x,
        y: button.y,
        size: button.size,
        itemID: button.itemID,
        command: button.commandString
    }))
}

export function rehydrateButtons() {
    liveButtons = config.buttons.map(data => 
        new InventoryButton(
            data.x, data.y, data.size,
            new Item(data.itemID),
            () => ChatLib.command(data.command),
            data.itemID, data.command
        )
    )
}

rehydrateButtons()

register("command", () => {
    config.enabled = !config.enabled
    config.save()
    ChatLib.chat("&a[InventoryButtons] &fToggled: " + (config.enabled ? "&aEnabled" : "&cDisabled"))
}).setName("invbtns")

register("command", (itemID, ...cmdParts) => {
    if (!itemID || cmdParts.length === 0) {
        ChatLib.chat("&cUsage: /invbtns_add <itemID> <command>")
        return
    }
    const command = cmdParts.join(" ")
    const buttonData = {
        x: 10,
        y: 16 + 25 * config.buttons.length,
        size: 16,
        itemID: itemID,
        command: command
    }
    
    config.buttons.push(buttonData)
    config.save()
    rehydrateButtons()
    ChatLib.chat(`&a[InventoryButtons] Button added with icon ${itemID} and command: ${command}`)
}).setName("invbtns_add")

register("command", () => {
    config.buttons = []
    config.save()
    rehydrateButtons()
    ChatLib.chat("&a[InventoryButtons] &eAll buttons cleared.")
}).setName("invbtns_clear")

const gui = new Gui()
let isOpen = false
export const isOpened = () => isOpen

register("command", () => {
    isOpen = true
    drag.register()
    gui.open()
}).setName("invbuttongui", true)

const image = new Image.fromFile("./config/Chattriggers/modules/InventoryButtons/inventory.png")

gui.registerDraw( (mx, my, partialTicks) => {
    Renderer.drawRect(Renderer.color(10, 10, 10, 150), 0, 0, Renderer.screen.getWidth(), Renderer.screen.getHeight())
    Renderer.drawStringWithShadow("&e&lInventory Buttons - Edit Mode\n&fLeft-click and drag to move.\n&fRight-click to delete.", 5, 5)

    Tessellator.pushMatrix()
    const width = image.getTextureWidth() * 0.25
    const height = image.getTextureHeight() * 0.25

    image.draw((Renderer.screen.getWidth() / 2) - (width / 2), (Renderer.screen.getHeight() / 2) - (height / 2), width, height)
    Tessellator.popMatrix()

    liveButtons.forEach(element => element.draw())
})

gui.registerClicked((mx, my, btn) => {
    if (btn === 0) {
        liveButtons.forEach(button => button.guiMouseClick(btn))
    } else if (btn === 1) {
        const indexToRemove = liveButtons.slice().reverse().findIndex(button => button.Hovered)
        if (indexToRemove !== -1) {
            const finalIndex = liveButtons.length - 1 - indexToRemove
            const removed = liveButtons.splice(finalIndex, 1)
            ChatLib.chat(`&a[InventoryButtons] &cRemoved button with command: /${removed[0].commandString}`)
        }
    }
})

gui.registerMouseReleased((mx, my, button) => {
    if (button === 0) liveButtons.forEach(element => element.clicked = false)
})

const drag = register(`dragged`, (dx, dy, mx, my, button) => {
    if (button === 0) {
        liveButtons.forEach(element => {
            if (element.clicked) {
                element.x += dx
                element.y += dy
            }
        })
    }
}).unregister()

gui.registerClosed(() => {
    isOpen = false
    dehydrateButtons()
    config.save()
    drag.unregister()
})


register(`postGuiRender`, () => {
    if (!config.enabled || Client.currentGui.getClassName() !== "GuiInventory") return
    
    Tessellator.pushMatrix()
    liveButtons.forEach(button => button.draw())
    Tessellator.popMatrix()
})

register(`guiMouseClick`, (_, __, btn) => { 
    if (!config.enabled || Client.currentGui.getClassName() !== "GuiInventory") return
    liveButtons.forEach(button => button.mouseClick(btn))
})