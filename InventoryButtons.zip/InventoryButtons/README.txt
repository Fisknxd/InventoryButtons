just inventory buttons as a ct module

commands:
- /invbtns_add <ItemID> <command> (without /)
- /invbtns_clear 
-invbuttonsgui

in the gui you can move the buttons around how ever you would like, right clicking on a button inside the gui will remove it.

IMPORTANT:
If you enter a itemid wrong you have to go inside data.json and change the itemid to a functional itemid. After you change it you just gotta /ct load to fix the issue. You can also change the size of the buttons within the data.json.

ps: the data.json will be created after the module loads.

enjoy
